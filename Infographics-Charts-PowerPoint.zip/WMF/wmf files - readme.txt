http://www.showeet.com
Contact: showeet[@]ymail.com

           ______________________________________
  ________|                                      |_______
  \       |       � Copyright Showeet.com        |      /
   \      |                                      |     /
   /      |______________________________________|     \
  /__________)                                (_________\



WMF = Windows Metafile
Image format that's designed to be scalable. Unlike other image formats (PNG, JPEG, etc.) WMF files use vectors to represent pictures so that no matter how much you stretch an image, it will never look pixelated.


HOW TO IMPORT THE WMF PICTURES IN YOUR POWERPOINT PRESENTATIONS ?


1/ Insert >> Pictures >> Select the WMF image >> Insert


(THEN) HOW TO EDIT & CHANGE THE COLORS ?


2/ Right-click on the image >> Group >> Ungroup

3/ Then you can edit et select all the parts of the image, and change the colors as needed

